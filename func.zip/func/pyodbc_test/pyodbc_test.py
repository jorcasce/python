from asyncio.log import logger
import pyodbc
import os
import azure.functions as func

from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential

import logging
import msal
import struct
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter(
    '%(asctime)s %(name)s %(levelname)-10s %(message)s')
formatter.converter = time.gmtime

sh = logging.StreamHandler()
sh.setLevel(logging.DEBUG)
sh.setFormatter(formatter)
logger.addHandler(sh)
logger.info('Start pyodbc test sql authentication')

class KeyVault:
    def __init__(self, kv_name):
        self._kv_name = kv_name
        self._kv_client = self.__get_kv_client()

    def __get_kv_url(self):
        return f"https://{self._kv_name}.vault.azure.net"

    def __get_kv_client(self):
        credential = DefaultAzureCredential()
        vault_url = self.__get_kv_url()
        return SecretClient(vault_url=vault_url, credential=credential)

    def get_secret(self, secret_name):
        return self._kv_client.get_secret(secret_name).value

# class SynapseConnection(object):
#     connection = None
#     cursor = None
#     def __init__(self, tenant_id, client_id, client_secret):
#         self._authority = f'https://login.microsoftonline.com/{tenant_id}'
#         self._scopes = ['https://database.windows.net/.default']
#         self._client_id = client_id
#         self._client_secret = client_secret
#         self.driver = '{ODBC Driver 17 for SQL Server}' #'{SQL Server Native Client 11.0}' '{ODBC Driver 17 for SQL Server}'
#         self.server = os.environ.get('DATABASE_HOSTNAME') or 'synrce2devdataeng.sql.azuresynapse.net'
#         self.db = 'staging'
#         self.dbconn = None
#         if SynapseConnection.connection is None:
#             try:
#                 logger.info('start SynapseConnection')
#                 SynapseConnection.connection =pyodbc.connect(self.get_conn_str(self.driver, self.server, self.db), attrs_before=self.get_conn_attrs(), autocommit=True)
#                 SynapseConnection.cursor = SynapseConnection.connection.cursor()
#             except Exception as error:
#                 logger.info("Error: Connection not established {}".format(error))
#             else:
#                 logger.info("Connection established")
#         else:
#             logger.info("Connection already exist")
#         self.connection = SynapseConnection.connection
#         self.cursor = SynapseConnection.cursor

#     def __modify_token_for_sql(self, token):
#         tokenb = bytes(token, "UTF-8")
#         exptoken = b''
#         for i in tokenb:
#             exptoken += bytes({i})
#             exptoken += bytes(1)
#         tokenstruct = struct.pack("=i", len(exptoken)) + exptoken
#         return tokenstruct

#     def get_access_token(self):
#         access_token = msal.ConfidentialClientApplication(
#             self._client_id, self._client_secret, self._authority).acquire_token_for_client(self._scopes)['access_token']
#         return access_token

#     def get_conn_attrs(self):
#         SQL_COPT_SS_ACCESS_TOKEN = 1256
#         return {SQL_COPT_SS_ACCESS_TOKEN: self.__modify_token_for_sql(self.get_access_token())}

#     def get_conn_str(self, driver, server, database):
#         conn_str = f'Driver={driver};Server=tcp:{server},1433;Database={database};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'
#         logger.info("conn_str")
#         logger.info(conn_str)
#         return conn_str


def cloud_function_entry(req: func.HttpRequest) -> func.HttpResponse:
    main()
    response = {
        "result": "Ran pyodbc test successfully"
    }

    logger.info('Finished processing HTTP Request in Azure function.')
    return func.HttpResponse(f'HTTP triggered function executed successfully. Response: {response}', status_code=200)


def main():
    # Use below for local testing
    ### LOGGING ###
    # app_key_vault_name = os.environ.get('KEY_VAULT_NAME') or 'kv-rc-e2-dev-ddpapp'
    # key_vault = KeyVault(app_key_vault_name)
    # tenant_id_secret_name = 'synapse-tenant-id'
    # client_id_secret_name = 'synapse-client-id'
    # client_secret_secret_name = 'synapse-client-secret'
    # tenant_id = key_vault.get_secret(tenant_id_secret_name)
    # client_id = key_vault.get_secret(client_id_secret_name)
    # client_secret = key_vault.get_secret(client_secret_secret_name)
    # with SynapseConnection(tenant_id, client_id, client_secret).cursor as cursor:
    #     cursor.execute('select top 2 [restaurant_num] from [simphony].[api_changes_extract]')
    #     rows = cursor.fetchall()
    #     for r in rows:
    #         logger.info(r)
    key_vault = KeyVault(os.environ.get('KEY_VAULT_NAME') or 'kv-rc-e2-dev-ddpapp')
    sql_pwd_secret_name = 'test-login1-pw'
    sql_pwd = key_vault.get_secret(sql_pwd_secret_name)
    sql_driver = '{ODBC Driver 17 for SQL Server}'
    cnxn = pyodbc.connect(f'DRIVER={sql_driver};SERVER=synrce2devdataeng.sql.azuresynapse.net;DATABASE=staging;UID=testLogin1;PWD={sql_pwd}')
    cursor = cnxn.cursor()
    cursor.execute("select top 2 [restaurant_num] from [simphony].[api_changes_extract]")
    rows = cursor.fetchall()
    for r in rows:
        logger.info(r)

if __name__ == '__main__':
    main()
